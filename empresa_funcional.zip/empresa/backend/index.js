const express = require('express');
const cors = require('cors');
require('dotenv').config();
const app = express();
app.use(cors());
app.use(express.json());

// Simulando rota de produtos
app.get('/api/produtos', (req, res) => {
    res.json([{ id: 1, nome: 'Cobre' }, { id: 2, nome: 'Alumínio' }]);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));