fetch('http://localhost:3000/api/produtos')
  .then(res => res.json())
  .then(data => {
    const div = document.getElementById('produtos');
    div.innerHTML = data.map(produto => `<p>${produto.nome}</p>`).join('');
  });